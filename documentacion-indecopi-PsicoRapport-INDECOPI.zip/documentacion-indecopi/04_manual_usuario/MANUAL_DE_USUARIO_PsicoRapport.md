# MANUAL DE USUARIO

## Software: PsicoRapport

**Versión documentada:** aplicación Android / PWA PsicoRapport  
**Idioma:** Español  
**Público:** usuarios finales (consultantes) y, en sección aparte, terapeutas  
**Fecha:** 18 de noviembre de 2026  
**Titular / editor del manual:** [COMPLETAR: nombres y apellidos]

---

## 0. Nota para la evaluación (INDECOPI)

Este manual describe **cómo se usa** el programa depositado. Complementa —no sustituye— la **memoria descriptiva** (qué es y cómo está construido) y el **código fuente** (expresión programática).

Se recomienda adjuntar **capturas de pantalla numeradas** (Login, Consentimiento, Chat, Mascota, Ánimo, Comunidad, Matching, Estadísticas) referenciadas como Figuras 1–N.

---

## 1. ¿Qué es PsicoRapport?

PsicoRapport es una aplicación de acompañamiento emocional que te permite:

- Conversar con tu compañero virtual (mascota personalizable).  
- Registrar cómo te sientes.  
- Cuidar y personalizar tu mascota (Objeto Digital Transicional).  
- Participar en una comunidad de apoyo.  
- Encontrar y vincularte con psicólogos / terapeutas verificados.  
- Ver tu progreso (puntos, rachas, etapa del camino).

**Importante:** PsicoRapport **no** es un psicólogo, psiquiatra ni servicio de emergencia. No diagnostica ni reemplaza terapia profesional. En crisis, contacta servicios locales de emergencia o la **línea 113** (Perú).

---

## 2. Requisitos

| Requisito | Detalle |
| --- | --- |
| Dispositivo | Teléfono Android compatible (app) o navegador moderno (PWA) |
| Cuenta | Cuenta de Google para iniciar sesión |
| Conexión | Internet |
| Edad | 18+; si eres menor, autorización de padre/madre/tutor |

---

## 3. Instalación e inicio

### 3.1 Instalación

1. Instale el archivo de la aplicación proporcionado (APK / tienda / AAB de distribución).  
2. Abra **PsicoRapport**.  
3. Si usa la versión web/PWA, puede agregarla a la pantalla de inicio cuando el sistema lo ofrezca.

### 3.2 Inicio de sesión (Figura 1 — Login)

1. Pulse el botón de acceso con Google.  
2. Elija su cuenta y autorice el acceso básico (perfil / correo).  
3. Si es la primera vez, continuará al **consentimiento informado**.

---

## 4. Consentimiento informado (Figura 2)

Antes de usar las funciones principales debe:

1. Leer el texto de consentimiento (desplácese hasta el final).  
2. Marcar las casillas de comprensión (naturaleza del servicio, no es terapia, privacidad, crisis).  
3. Aceptar para continuar.

Sin este paso, el sistema no habilita el resto de módulos.

---

## 5. Onboarding / preferencias (Figura 3)

Complete los datos iniciales que el sistema solicita (por ejemplo: información de acompañamiento, motivo, preferencia de estilo terapéutico).  
Estos datos ayudan a personalizar el acompañamiento y las recomendaciones de profesionales.

---

## 6. Pantalla principal: chat con tu mascota (Figura 4)

Ruta principal de acompañamiento.

### 6.1 Cómo conversar

1. Escriba un mensaje en el cuadro de texto.  
2. Envíe el mensaje.  
3. Reciba la respuesta de su compañero virtual (por defecto, **Qori**).  

Puede hablar de cómo se siente, pedir calma, preguntar por su progreso o por profesionales disponibles.

### 6.2 Acciones sugeridas

En algunos casos la app muestra botones/atajos, por ejemplo:

- Registrar ánimo  
- Cuidar a la mascota  
- Ver psicólogos / matching  
- Llamar a línea de crisis (113)

### 6.3 Etapas del camino

El sistema reconoce etapas:

1. **Dependencia** — acompañamiento cercano con la mascota.  
2. **Independencia** — mayor autonomía (tras uso sostenido: ánimo, cuidados, chat o racha).  
3. **Puente terapéutico** — cuando se vincula con un terapeuta humano.

---

## 7. Mascota virtual (Figura 5)

Desde la sección de mascota usted puede:

1. Ver el estado (hambre, felicidad, energía) y la emoción actual.  
2. **Personalizar** nombre (dentro del límite permitido), color y accesorio.  
3. **Cuidar** la mascota:  
   - Alimentar  
   - Jugar  
   - Descansar  

Si no la cuida por un tiempo, sus indicadores pueden bajar (decaimiento).

Las caras de emoción (triste, enojado, temeroso, calma, motivado, feliz) reflejan el estado vinculado al ánimo / cuidado.

---

## 8. Registro de estado de ánimo (Figura 6)

1. Ingrese a la sección de seguimiento / diario de ánimo.  
2. Seleccione la emoción que mejor describe cómo se siente.  
3. Guarde el registro.  

Los registros alimentan estadísticas, la mascota y el contexto del chat.

---

## 9. Comunidad (Figura 7)

1. Lea publicaciones de otras personas.  
2. Cree una publicación de apoyo (texto).  
3. Reaccione con “me gusta” o comente.  

Recibirá notificaciones cuando interactúen con sus publicaciones (si las notificaciones están activas).  
Mantenga un tono respetuoso; no es un espacio de diagnóstico entre pares.

---

## 10. Terapeutas y matching (Figura 8)

### 10.1 Explorar profesionales

1. Abra el listado de terapeutas.  
2. Revise fichas (especialidad, enfoque, presentación).  
3. Elija un profesional cuando se sienta listo.

### 10.2 Matching

Use el flujo de matching para orientar la búsqueda según preferencias (p. ej. estilo terapéutico).  
El vínculo con un profesional se asocia a la etapa de **puente terapéutico**.

---

## 11. Progreso y estadísticas (Figura 9)

Consulte:

- Puntos acumulados por acciones de autocuidado  
- Rachas de uso  
- Resumen de actividad (chat, ánimo, cuidados, comunidad)  
- Etapa actual del camino

---

## 12. Navegación

La barra inferior (dock) permite saltar entre las secciones principales (chat, mascota, ánimo, comunidad, perfil/progreso, según la versión).  
En Android, el botón “atrás” sigue el historial de pantallas; en pantallas raíz puede cerrar la app.

---

## 13. Manual breve para terapeutas

1. Inicie sesión con Google.  
2. Complete el registro de terapeuta (datos profesionales, especialidad, biografía, etc.).  
3. Espere la verificación / aprobación según el flujo administrativo.  
4. Una vez aprobado, su perfil podrá aparecer para usuarios en búsqueda / matching.

---

## 14. Privacidad y seguridad (resumen para el usuario)

- Se solicitan datos necesarios para la cuenta y el acompañamiento.  
- Usted controla el consentimiento informado.  
- No comparta datos sensibles de terceros en la comunidad.  
- Para eliminar cuenta o ejercer derechos, contacte a: [COMPLETAR: correo de soporte].

---

## 15. Solución de problemas frecuentes

| Problema | Qué intentar |
| --- | --- |
| No inicia sesión | Verificar Internet y cuenta Google; reintentar |
| Lo envían siempre al consentimiento | Completar casillas y aceptar |
| No carga el chat | Verificar conexión; reabrir la app |
| No llegan notificaciones | Activar permisos de notificación del sistema |
| La mascota “baja” de ánimo | Usar acciones de cuidado (alimentar / jugar / descansar) |

---

## 16. Contacto

- Soporte: [COMPLETAR: correo]  
- Titular del software: [COMPLETAR: nombre]

---

## 17. Anexos recomendados (adjuntar al expediente)

| Anexo | Contenido |
| --- | --- |
| Anexo A | Capturas Figuras 1–9 |
| Anexo B | Ejecutable AAB/APK |
| Anexo C | Memoria descriptiva |
| Anexo D | Partes sustanciales del código fuente |

**Fin del manual de usuario.**
