# Índice de partes sustanciales del código fuente — PsicoRapport

**Programa:** PsicoRapport  
**Lenguaje principal:** JavaScript (ECMAScript) + Vue 3 (Single File Components)  
**Plataforma:** Aplicación móvil híbrida (Capacitor / Android) y Progressive Web App  
**Fecha de preparación del depósito:** 18 de noviembre de 2026  
**Autor / titular:** [COMPLETAR: nombres y apellidos completos]  
**Commit de referencia (GitHub):** `c33254434addcf4db93e80e3278604a3a76829f4`  
**Repositorio:** https://github.com/antonyayansi/psico-rapport  

---

## 1. Criterio de selección

Se depositan las **partes sustanciales** que expresan la originalidad del programa:

- lógica propia del **Objeto Digital Transicional (ODT)** y etapas de transición;
- agente conversacional con herramientas (function calling);
- mascota virtual, emociones, cuidado y personalización;
- gamificación y avance de etapas;
- pantallas y flujos de usuario (consentimiento, chat, ánimo, matching, comunidad, terapeutas);
- backend de notificaciones (Cloud Functions).

Se **omiten deliberadamente** secretos de producción (claves API, credenciales AWS/Firebase) mediante versiones sanitizadas, sin alterar la estructura ni la expresión lógica del código.

---

## 2. Inventario de archivos depositados

### 2.1 Núcleo creativo / dominio propio

| Archivo | Descripción de la expresión protegida |
| --- | --- |
| `src/transition.js` | Modelo de etapas dependencia → independencia → puente terapéutico; prompts del agente por etapa; umbrales de avance |
| `src/pet.js` | Mascota ODT “Qori”: colores, accesorios, emociones, cuidado (alimentar/jugar/descansar), decaimiento |
| `src/gamification.js` | Puntos, rachas, conteos de acciones y avance automático de etapa |
| `src/agent/uwuAgent.js` | Bucle del agente conversacional con herramientas (múltiples rondas) |
| `src/agent/uwuTools.js` | Catálogo de tools, acciones de app, crisis (línea 113), registro de ánimo, matching |

### 2.2 Arquitectura de aplicación y navegación

| Archivo | Descripción |
| --- | --- |
| `src/main.js` | Punto de entrada Vue |
| `src/App.vue` | Contenedor raíz |
| `src/style.css` | Estilos / identidad visual en CSS |
| `src/router/index.js` | Rutas, guards de autenticación, consentimiento y rol admin |
| `src/stores/auth.js` | Estado de autenticación y consentimiento |
| `src/firebase.js` | Inicialización Firebase (**credenciales omitidas**) |
| `src/aws.js` | Carga de archivos a S3 (**credenciales omitidas**) |

### 2.3 Interfaces de usuario (expresión visual + interacción)

| Archivo | Módulo |
| --- | --- |
| `src/views/LoginView.vue` | Acceso |
| `src/views/ConsentView.vue` | Consentimiento informado |
| `src/views/OnboardingView.vue` | Preferencias iniciales |
| `src/views/UwuChatView.vue` | Chat con la mascota / agente |
| `src/views/PetView.vue` | Cuidado y personalización de mascota |
| `src/views/TrackingView.vue` | Registro de estados de ánimo |
| `src/views/MatchingView.vue` | Emparejamiento con terapeutas |
| `src/views/TherapistsView.vue` | Listado de profesionales |
| `src/views/TherapistRegisterView.vue` | Alta de terapeutas |
| `src/views/CommunityView.vue` | Comunidad / foro de apoyo |
| `src/views/ProfileStatsView.vue` | Progreso y estadísticas |
| `src/components/BottomDock.vue` | Navegación inferior |
| `src/components/PetAvatar.vue` | Representación visual de la mascota |
| `src/components/QuietConfirm.vue` | Diálogo de confirmación |

### 2.4 Servicios auxiliares y backend

| Archivo | Descripción |
| --- | --- |
| `src/composables/useFCM.js` | Notificaciones push |
| `src/composables/useInstallPrompt.js` | Instalación PWA |
| `functions/index.js` | Cloud Functions: likes, comentarios, eventos |

### 2.5 Configuración del producto

| Archivo | Descripción |
| --- | --- |
| `config/package.json` | Dependencias y scripts |
| `config/capacitor.config.json` | Empaquetado Android (`appName`: PsicoRapport) |

---

## 3. Declaración

El presente depósito corresponde al código fuente desarrollado para el programa **PsicoRapport**. Las bibliotecas de terceros (Vue, Firebase, Capacitor, etc.) se utilizan como herramientas; la originalidad reclamada recae en la **organización funcional**, la **lógica de dominio** y la **expresión de interfaces** propias del programa.

**Firma del titular:** _______________________________  
**Fecha:** ____ / ____ / ________
